package com.myhindglobal.bellavite

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/** Festival greetings, fully offline. Shown from 1 day before to 1 day after. Dated list covers 2026-2027; extend yearly. */
object Festivals {
    class F(val hi: String, val en: String)

    private val holi = F("हैप्पी होली", "Happy Holi")
    private val eid = F("ईद मुबारक", "Eid Mubarak")
    private val adha = F("ईद-उल-अज़हा मुबारक", "Eid al-Adha Mubarak")
    private val rakhi = F("रक्षाबंधन की शुभकामनाएँ", "Happy Raksha Bandhan")
    private val janm = F("जन्माष्टमी की शुभकामनाएँ", "Happy Janmashtami")
    private val ganesh = F("गणपति बाप्पा मोरया", "Happy Ganesh Chaturthi")
    private val dussehra = F("दशहरे की शुभकामनाएँ", "Happy Dussehra")
    private val diwali = F("हैप्पी दिवाली", "Happy Diwali")
    private val gurpurab = F("गुरुपर्व की शुभकामनाएँ", "Happy Gurpurab")

    private val fixed = listOf(
        Triple(1, 1, F("नया साल मुबारक", "Happy New Year")),
        Triple(1, 26, F("गणतंत्र दिवस की शुभकामनाएँ", "Happy Republic Day")),
        Triple(8, 15, F("स्वतंत्रता दिवस की शुभकामनाएँ", "Happy Independence Day")),
        Triple(10, 2, F("गांधी जयंती", "Gandhi Jayanti")),
        Triple(12, 25, F("मेरी क्रिसमस", "Merry Christmas"))
    )

    private val dated = listOf(
        "2026-03-04" to holi, "2027-03-22" to holi,
        "2026-03-21" to eid, "2027-03-10" to eid,
        "2026-05-27" to adha, "2027-05-17" to adha,
        "2026-08-28" to rakhi, "2027-08-17" to rakhi,
        "2026-09-04" to janm, "2027-08-25" to janm,
        "2026-09-14" to ganesh, "2027-09-04" to ganesh,
        "2026-10-20" to dussehra, "2027-10-09" to dussehra,
        "2026-11-08" to diwali, "2027-10-29" to diwali,
        "2026-11-24" to gurpurab, "2027-11-14" to gurpurab
    )

    private var cachedDay: LocalDate? = null
    private var cached: F? = null

    fun today(): F? {
        val d = LocalDate.now()
        if (d == cachedDay) return cached
        cachedDay = d
        cached = compute(d)
        return cached
    }

    private fun compute(d: LocalDate): F? {
        for ((m, day, f) in fixed) if (d.monthValue == m && d.dayOfMonth == day) return f
        var best: F? = null
        var bd = 9L
        for ((s, f) in dated) {
            val diff = abs(ChronoUnit.DAYS.between(LocalDate.parse(s), d))
            if (diff <= 1 && diff < bd) { bd = diff; best = f }
        }
        if (best != null) return best
        try {
            val hd = HijrahDate.from(d)
            val m = hd.get(ChronoField.MONTH_OF_YEAR)
            val k = hd.get(ChronoField.DAY_OF_MONTH)
            if ((m == 10 && k <= 2) || (m == 9 && k == 30)) return eid
            if (m == 12 && k in 9..11) return adha
        } catch (e: Exception) { }
        return null
    }
}
