package com.myhindglobal.bellavite

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

const val DEFAULT_NAME = "IMRAN FANCY Boutique"

/** Themes: 0 fish, 1 flowers, 2 waterfall, 3 mountains, 4 customer's own gallery photo. */
const val THEME_PHOTO = 4

class ClockWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ClockEngine()

    private class Fish(val yf: Float, val size: Float, val speed: Float, val dir: Int, val color: Int, val phase: Float)

    inner class ClockEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private val frame = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 40)
            }
        }

        private val prefs by lazy { getSharedPreferences("bv", MODE_PRIVATE) }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val path = Path()
        private var pmFlag = false
        private val bodyPath = Path().apply {
            moveTo(0f, 0f); cubicTo(8f, -16f, 34f, -18f, 54f, -3f); cubicTo(58f, -1f, 58f, 1f, 54f, 3f); cubicTo(34f, 18f, 8f, 16f, 0f, 0f); close()
        }
        private val tailPath = Path().apply {
            moveTo(2f, 0f); cubicTo(-8f, -14f, -18f, -16f, -20f, -12f); cubicTo(-14f, -4f, -14f, 4f, -20f, 12f); cubicTo(-18f, 16f, -8f, 14f, 2f, 0f); close()
        }
        private val finPath = Path().apply {
            moveTo(14f, -13f); cubicTo(20f, -26f, 34f, -24f, 38f, -14f); cubicTo(30f, -16f, 22f, -15f, 14f, -13f); close()
        }
        private val fishes = listOf(
            Fish(0.16f, 1.8f, 28f, 1, 0xFFFF7A59.toInt(), 0.0f),
            Fish(0.27f, 1.6f, 24f, -1, 0xFF4FD1C5.toInt(), 0.4f),
            Fish(0.375f, 1.5f, 20f, 1, 0xFFF6C945.toInt(), 0.7f),
            Fish(0.62f, 2.1f, 30f, -1, 0xFFFF6FB1.toInt(), 0.15f),
            Fish(0.73f, 1.9f, 22f, 1, 0xFF8B7CF6.toInt(), 0.55f),
            Fish(0.83f, 1.7f, 26f, -1, 0xFF5EC8FF.toInt(), 0.85f),
            Fish(0.91f, 1.4f, 18f, 1, 0xFF7BE069.toInt(), 0.3f)
        )
        private val months = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        private val days = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        private val sparkX = floatArrayOf(0.15f, 0.85f, 0.28f, 0.75f, 0.10f, 0.92f, 0.22f, 0.80f, 0.38f, 0.65f, 0.50f, 0.06f)
        private val sparkY = floatArrayOf(0.19f, 0.26f, 0.33f, 0.07f, 0.42f, 0.54f, 0.75f, 0.70f, 0.88f, 0.86f, 0.12f, 0.68f)

        private var bgFish: RadialGradient? = null
        private var bgFlower: RadialGradient? = null
        private var bgSky: LinearGradient? = null
        private var bgForest: LinearGradient? = null
        private var bgW = 0
        private var bgH = 0
        private var photo: Bitmap? = null
        private var photoVer = -1L
        private val photoMatrix = Matrix()

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(frame)
            if (v) handler.post(frame)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(frame)
            super.onDestroy()
        }

        private fun fresh() { p.reset(); p.isAntiAlias = true }

        private fun drawFrame() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = holder.lockCanvas()
                if (c != null) render(c)
            } catch (e: Exception) {
            } finally {
                if (c != null) try { holder.unlockCanvasAndPost(c) } catch (e: Exception) { }
            }
        }

        private fun render(c: Canvas) {
            val w = c.width.toFloat()
            val h = c.height.toFloat()
            val t = SystemClock.uptimeMillis() / 1000f
            // Same big, centred clock in every theme; with the customer's own photo it is drawn transparent (see overlay)
            val photoMode = prefs.getInt("theme", 0) == THEME_PHOTO && File(filesDir, "bg.jpg").exists()
            pmFlag = photoMode
            val r = w * 0.40f
            val cx = w / 2f
            val cy = h * 0.40f

            if (bgW != c.width || bgH != c.height) {
                bgW = c.width; bgH = c.height
                bgFish = RadialGradient(cx, h * 0.42f, max(w, h) * 0.8f,
                    intArrayOf(0xFF4D1440.toInt(), 0xFF2A0F26.toInt(), 0xFF120A14.toInt()),
                    floatArrayOf(0f, 0.45f, 0.85f), Shader.TileMode.CLAMP)
                bgFlower = RadialGradient(cx, h * 0.45f, max(w, h) * 0.85f,
                    intArrayOf(0xFF8A2A55.toInt(), 0xFF4A1235.toInt(), 0xFF1A0A1E.toInt()),
                    floatArrayOf(0f, 0.5f, 0.95f), Shader.TileMode.CLAMP)
                bgSky = LinearGradient(0f, 0f, 0f, h,
                    intArrayOf(0xFF1F2F5E.toInt(), 0xFFD9736B.toInt(), 0xFFF6C177.toInt()),
                    floatArrayOf(0f, 0.55f, 0.82f), Shader.TileMode.CLAMP)
                bgForest = LinearGradient(0f, 0f, 0f, h,
                    intArrayOf(0xFF0B2420.toInt(), 0xFF1B4D3E.toInt(), 0xFF0A1B17.toInt()),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            }

            when (prefs.getInt("theme", 0)) {
                1 -> themeFlowers(c, w, h, t)
                2 -> themeWaterfall(c, w, h, t)
                3 -> themeMountains(c, w, h, t)
                THEME_PHOTO -> if (!themePhoto(c, w, h)) themeFish(c, w, h, t, cx, cy, r)
                else -> themeFish(c, w, h, t, cx, cy, r)
            }

            overlay(c, w, h, cx, cy, r)
        }

        // ---------- THEMES ----------

        private fun themeFish(c: Canvas, w: Float, h: Float, t: Float, cx: Float, cy: Float, r: Float) {
            fresh(); p.shader = bgFish
            c.drawRect(0f, 0f, w, h, p)

            fresh(); p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.003f; p.color = 0x52E8C26A.toInt()
            c.save(); c.translate(cx, cy); c.rotate(t * 2.4f)
            for (i in 0 until 8) {
                c.save(); c.rotate(i * 45f)
                rect.set(-r * 0.2f, -r * 1.55f, r * 0.2f, -r * 0.95f); c.drawOval(rect, p)
                c.restore()
                c.save(); c.rotate(i * 45f + 22.5f)
                rect.set(-r * 0.17f, -r * 1.3f, r * 0.17f, -r * 0.8f); c.drawOval(rect, p)
                c.restore()
            }
            c.restore()

            flower(c, w * 0.08f, h * 0.05f, w * 0.22f, 0f)
            flower(c, w * 0.95f, h * 0.11f, w * 0.15f, 0f)
            flower(c, w * 0.90f, h * 0.43f, w * 0.09f, 0f)
            flower(c, w * 0.05f, h * 0.56f, w * 0.12f, 0f)
            flower(c, w * 0.15f, h * 0.96f, w * 0.18f, 0f)
            flower(c, w * 0.93f, h * 0.93f, w * 0.25f, 0f)

            for (f in fishes) fish(c, f, w, h, t)

            for (i in sparkX.indices) {
                val a = ((sin(t * 1.8f + i) + 1f) / 2f * 230f).toInt()
                fresh(); p.style = Paint.Style.FILL; p.color = Color.argb(a, 255, 241, 194)
                c.drawCircle(w * sparkX[i], h * sparkY[i], w * 0.004f, p)
            }
        }

        private fun themeFlowers(c: Canvas, w: Float, h: Float, t: Float) {
            fresh(); p.shader = bgFlower
            c.drawRect(0f, 0f, w, h, p)
            // big slowly turning flowers
            flower(c, w * 0.10f, h * 0.10f, w * 0.30f, t * 4f)
            flower(c, w * 0.92f, h * 0.20f, w * 0.22f, -t * 5f)
            flower(c, w * 0.06f, h * 0.55f, w * 0.20f, -t * 4f)
            flower(c, w * 0.95f, h * 0.62f, w * 0.26f, t * 3f)
            flower(c, w * 0.20f, h * 0.92f, w * 0.30f, t * 3f)
            flower(c, w * 0.85f, h * 0.95f, w * 0.28f, -t * 4f)
            flower(c, w * 0.50f, h * 0.01f, w * 0.14f, t * 6f)
            // falling petals
            for (i in 0 until 26) {
                val sp = 0.035f + (i % 5) * 0.012f
                val y = ((t * sp + i * 0.137f) % 1f) * (h + 80f) - 40f
                val x = w * ((i * 0.173f) % 1f) + sin(t * 0.7f + i) * w * 0.04f
                fresh(); p.style = Paint.Style.FILL
                p.color = if (i % 2 == 0) 0xB3FF9EC4.toInt() else 0xB3FFD27A.toInt()
                c.save(); c.translate(x, y); c.rotate(t * 40f + i * 30f)
                rect.set(-w * 0.012f, -w * 0.02f, w * 0.012f, w * 0.02f); c.drawOval(rect, p)
                c.restore()
            }
        }

        private fun themeMountains(c: Canvas, w: Float, h: Float, t: Float) {
            fresh(); p.shader = bgSky
            c.drawRect(0f, 0f, w, h, p)
            // sun with glow
            fresh(); p.shader = RadialGradient(w * 0.72f, h * 0.50f, w * 0.38f,
                intArrayOf(0xCCFFE2A8.toInt(), 0x00FFE2A8), null, Shader.TileMode.CLAMP)
            c.drawCircle(w * 0.72f, h * 0.50f, w * 0.38f, p)
            fresh(); p.color = 0xFFFFF1C2.toInt(); c.drawCircle(w * 0.72f, h * 0.50f, w * 0.08f, p)
            // drifting clouds
            for (i in 0 until 5) {
                val x = ((t * (6f + i * 2f) + i * w * 0.37f) % (w * 1.4f)) - w * 0.2f
                val y = h * (0.12f + 0.07f * i)
                fresh(); p.color = 0x55FFFFFF
                rect.set(x, y, x + w * 0.28f, y + w * 0.06f); c.drawOval(rect, p)
                rect.set(x + w * 0.06f, y - w * 0.03f, x + w * 0.2f, y + w * 0.04f); c.drawOval(rect, p)
            }
            ridge(c, w, h, h * 0.62f, h * 0.12f, 1f, 0xFF6B5B8A.toInt())
            ridge(c, w, h, h * 0.72f, h * 0.14f, 2.5f, 0xFF45386E.toInt())
            ridge(c, w, h, h * 0.84f, h * 0.15f, 4f, 0xFF271F45.toInt())
            // birds
            for (i in 0 until 4) {
                val x = ((t * (28f + i * 9f) + i * w * 0.3f) % (w + 120f)) - 60f
                val y = h * (0.20f + 0.035f * i) + sin(t * 2f + i) * 8f
                val flap = sin(t * 7f + i) * w * 0.012f
                fresh(); p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.004f; p.strokeCap = Paint.Cap.ROUND; p.color = 0xCC1A1428.toInt()
                c.drawLine(x - w * 0.02f, y - flap, x, y, p)
                c.drawLine(x, y, x + w * 0.02f, y - flap, p)
            }
        }

        private fun themeWaterfall(c: Canvas, w: Float, h: Float, t: Float) {
            fresh(); p.shader = bgForest
            c.drawRect(0f, 0f, w, h, p)
            // cliffs
            fresh(); p.color = 0xFF2B2B33.toInt()
            path.reset(); path.moveTo(0f, h * 0.20f); path.lineTo(w * 0.42f, h * 0.28f); path.lineTo(w * 0.40f, h * 0.67f); path.lineTo(0f, h * 0.72f); path.close()
            c.drawPath(path, p)
            path.reset(); path.moveTo(w, h * 0.20f); path.lineTo(w * 0.58f, h * 0.28f); path.lineTo(w * 0.60f, h * 0.67f); path.lineTo(w, h * 0.72f); path.close()
            c.drawPath(path, p)
            // flowing water
            c.save(); c.clipRect(w * 0.42f, h * 0.28f, w * 0.58f, h * 0.67f)
            fresh(); p.color = 0xFF2F7FA0.toInt(); c.drawRect(w * 0.42f, h * 0.28f, w * 0.58f, h * 0.67f, p)
            for (i in 0 until 18) {
                val x = w * (0.425f + 0.15f * i / 17f) + sin(t + i) * w * 0.003f
                val y0 = h * 0.28f + (((t * (0.30f + 0.05f * (i % 4)) + i * 0.173f) % 1f) * (h * 0.46f)) - h * 0.1f
                fresh(); p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.006f; p.strokeCap = Paint.Cap.ROUND
                p.color = Color.argb(150 + (i % 3) * 30, 235, 250, 255)
                c.drawLine(x, y0, x, y0 + h * 0.11f, p)
            }
            c.restore()
            // pool
            fresh(); p.shader = LinearGradient(0f, h * 0.67f, 0f, h * 0.86f,
                intArrayOf(0xFF2A8AA8.toInt(), 0xFF0F3E52.toInt()), null, Shader.TileMode.CLAMP)
            rect.set(w * 0.04f, h * 0.67f, w * 0.96f, h * 0.86f); c.drawOval(rect, p)
            for (i in 0 until 3) {
                val k = ((t * 0.25f + i / 3f) % 1f)
                fresh(); p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.003f; p.color = Color.argb(((1f - k) * 120).toInt(), 255, 255, 255)
                val rw = w * (0.08f + 0.35f * k)
                rect.set(w * 0.5f - rw, h * 0.765f - rw * 0.25f, w * 0.5f + rw, h * 0.765f + rw * 0.25f); c.drawOval(rect, p)
            }
            // mist
            for (i in 0 until 3) {
                val a = ((sin(t * 0.8f + i * 2f) + 1f) / 2f * 70f + 40f).toInt()
                fresh(); p.color = Color.argb(a, 255, 255, 255)
                rect.set(w * (0.30f + 0.05f * i), h * 0.64f, w * (0.70f - 0.05f * i), h * 0.71f); c.drawOval(rect, p)
            }
            // foreground trees
            fresh(); p.color = 0xFF08140F.toInt()
            for (i in 0 until 6) {
                val bx = if (i < 3) w * (0.02f + 0.1f * i) else w * (0.72f + 0.1f * (i - 3))
                path.reset(); path.moveTo(bx, h); path.lineTo(bx + w * 0.07f, h * (0.80f - 0.02f * (i % 3))); path.lineTo(bx + w * 0.14f, h); path.close()
                c.drawPath(path, p)
            }
        }

        /** Customer's own photo from the gallery, centre-cropped, slightly dimmed so the clock stays readable. */
        private fun themePhoto(c: Canvas, w: Float, h: Float): Boolean {
            val ver = prefs.getLong("photo_ver", 0L)
            if (ver != photoVer) {
                photoVer = ver
                photo = try {
                    val f = File(filesDir, "bg.jpg")
                    if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
                } catch (e: Exception) { null }
            }
            val b = photo ?: return false
            val s = max(w / b.width, h / b.height)
            photoMatrix.reset()
            photoMatrix.setScale(s, s)
            photoMatrix.postTranslate((w - b.width * s) / 2f, (h - b.height * s) / 2f)
            fresh(); p.isFilterBitmap = true
            c.drawBitmap(b, photoMatrix, p)
            fresh(); p.color = Color.argb(95, 0, 0, 0)
            c.drawRect(0f, 0f, w, h, p)
            return true
        }

        private fun ridge(c: Canvas, w: Float, h: Float, baseY: Float, amp: Float, seed: Float, color: Int) {
            path.reset(); path.moveTo(0f, h)
            val n = 48
            for (i in 0..n) {
                val xf = i / n.toFloat()
                val y = baseY - amp * (abs(sin(xf * 3.2f + seed)) * 0.7f + abs(sin(xf * 7.1f + seed * 1.7f)) * 0.3f)
                path.lineTo(w * xf, y)
            }
            path.lineTo(w, h); path.close()
            fresh(); p.color = color
            c.drawPath(path, p)
        }

        // ---------- CLOCK + TEXT (common to every theme) ----------

        private fun overlay(c: Canvas, w: Float, h: Float, cx: Float, cy: Float, r: Float) {
            val pm = pmFlag
            // header + festival greeting
            fresh(); p.textAlign = Paint.Align.CENTER; p.color = if (pm) Color.WHITE else 0xFFE3D3B8.toInt(); p.textSize = w * 0.034f
            p.setShadowLayer(w * 0.01f, 0f, 0f, 0xCC000000.toInt())
            c.drawText("Powered by ION (My Hind Global)", w / 2f, h * 0.065f, p)
            val fest = Festivals.today()
            if (fest != null) {
                fresh(); p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
                p.color = if (pm) Color.WHITE else 0xFFFFF1C2.toInt(); p.textSize = w * 0.075f
                p.setShadowLayer(w * 0.02f, 0f, 0f, if (pm) 0xCC000000.toInt() else 0xCCE8C26A.toInt())
                c.drawText(fest.hi, w / 2f, h * 0.115f, p)
                fresh(); p.textAlign = Paint.Align.CENTER; p.color = if (pm) Color.WHITE else 0xFFE3D3B8.toInt(); p.textSize = w * 0.032f
                p.setShadowLayer(w * 0.01f, 0f, 0f, 0xCC000000.toInt())
                c.drawText(fest.en.uppercase(), w / 2f, h * 0.145f, p)
            }

            // clock rim + face
            fresh()
            p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r,
                intArrayOf(0xFFFFF1C2.toInt(), 0xFFC8963E.toInt(), 0xFFF3D487.toInt()), null, Shader.TileMode.CLAMP)
            if (pm) {
                fresh(); p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.025f; p.color = Color.WHITE
                p.setShadowLayer(r * 0.03f, 0f, 0f, 0xCC000000.toInt()); c.drawCircle(cx, cy, r * 0.97f, p)
            } else c.drawCircle(cx, cy, r, p)
            fresh(); p.color = if (pm) 0x22000000 else 0xF21B0D1C.toInt(); c.drawCircle(cx, cy, r * 0.95f, p)

            for (i in 0 until 60) {
                val big = i % 5 == 0
                val a = Math.toRadians(i * 6.0)
                val r1 = r * (if (big) 0.84f else 0.88f)
                val r2 = r * 0.92f
                fresh(); p.style = Paint.Style.STROKE; p.strokeWidth = if (big) r * 0.02f else r * 0.008f
                p.color = if (pm) Color.WHITE else if (big) 0xFFE8C26A.toInt() else 0xFF8D7A5C.toInt()
                if (pm) p.setShadowLayer(r * 0.015f, 0f, 0f, 0xCC000000.toInt())
                c.drawLine(cx + sin(a).toFloat() * r1, cy - cos(a).toFloat() * r1,
                    cx + sin(a).toFloat() * r2, cy - cos(a).toFloat() * r2, p)
            }
            fresh(); p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            p.color = if (pm) Color.WHITE else 0xFFF6EAD2.toInt(); p.textSize = r * 0.16f
            if (pm) p.setShadowLayer(r * 0.04f, 0f, 0f, 0xDD000000.toInt())
            for (n in 1..12) {
                val a = Math.toRadians(n * 30.0)
                c.drawText(n.toString(), cx + sin(a).toFloat() * r * 0.68f, cy - cos(a).toFloat() * r * 0.68f + r * 0.055f, p)
            }

            val cal = Calendar.getInstance()
            rect.set(cx - r * 0.32f, cy + r * 0.24f, cx + r * 0.32f, cy + r * 0.48f)
            fresh(); p.color = if (pm) 0x33000000 else 0xFF0D060E.toInt(); c.drawRoundRect(rect, r * 0.04f, r * 0.04f, p)
            fresh(); p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.01f; p.color = if (pm) Color.WHITE else 0xFFE8C26A.toInt()
            c.drawRoundRect(rect, r * 0.04f, r * 0.04f, p)
            fresh(); p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = r * 0.115f
            if (pm) p.setShadowLayer(r * 0.03f, 0f, 0f, 0xDD000000.toInt())
            p.typeface = Typeface.DEFAULT; p.color = if (pm) Color.WHITE else 0xFFFFD27A.toInt(); c.drawText(days[cal.get(Calendar.DAY_OF_WEEK) - 1], cx - r * 0.16f, cy + r * 0.405f, p)
            p.typeface = Typeface.DEFAULT; p.color = if (pm) Color.WHITE else 0xFF8FD8FF.toInt(); c.drawText("${cal.get(Calendar.DAY_OF_MONTH)} ${months[cal.get(Calendar.MONTH)]}", cx + r * 0.16f, cy + r * 0.405f, p)

            val s = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
            val m = cal.get(Calendar.MINUTE) + s / 60f
            val hr = cal.get(Calendar.HOUR) + m / 60f
            hand(c, cx, cy, hr * 30f, r * 0.50f, r * 0.045f, 0xFFF6EAD2.toInt())
            hand(c, cx, cy, m * 6f, r * 0.75f, r * 0.028f, 0xFFF6EAD2.toInt())
            hand(c, cx, cy, s * 6f, r * 0.86f, r * 0.012f, 0xFFE8C26A.toInt())
            fresh(); p.color = 0xFFE8C26A.toInt(); c.drawCircle(cx, cy, r * 0.05f, p)
            p.color = 0xFF120A14.toInt(); c.drawCircle(cx, cy, r * 0.018f, p)

            // footer brand (editable from the app screen)
            val name = prefs.getString("name", DEFAULT_NAME) ?: DEFAULT_NAME
            fresh(); p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD; p.color = Color.WHITE
            var size = w * 0.07f
            p.textSize = size
            while (p.measureText(name) > w * 0.9f && size > 10f) { size *= 0.92f; p.textSize = size }
            p.setShadowLayer(w * 0.025f, 0f, 0f, if (pm) 0xCC000000.toInt() else 0xB3FFFFFF.toInt())
            c.drawText(name, w / 2f, h * 0.76f, p)
            fresh(); p.textAlign = Paint.Align.CENTER; p.color = 0xCCFFFFFF.toInt(); p.textSize = w * 0.028f
            p.setShadowLayer(w * 0.01f, 0f, 0f, 0xCC000000.toInt())
            c.drawText("Powered by ION Core Ecosystem · My Hind Global", w / 2f, h * 0.795f, p)
        }

        private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, wd: Float, color: Int) {
            val a = Math.toRadians(deg.toDouble())
            fresh(); p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = wd; p.color = if (pmFlag) Color.WHITE else color
            if (pmFlag) p.setShadowLayer(wd * 0.5f, 0f, 0f, 0xDD000000.toInt())
            c.drawLine(cx - sin(a).toFloat() * len * 0.12f, cy + cos(a).toFloat() * len * 0.12f,
                cx + sin(a).toFloat() * len, cy - cos(a).toFloat() * len, p)
        }

        private fun flower(c: Canvas, x: Float, y: Float, r: Float, rot: Float) {
            c.save(); c.translate(x, y); c.rotate(rot)
            fresh(); p.style = Paint.Style.FILL; p.color = 0x8CD6457F.toInt()
            for (i in 0 until 8) {
                c.save(); c.rotate(i * 45f)
                rect.set(-r * 0.22f, -r, r * 0.22f, 0f); c.drawOval(rect, p)
                c.restore()
            }
            p.color = 0xB3F3B04C.toInt()
            for (i in 0 until 8) {
                c.save(); c.rotate(i * 45f + 22.5f)
                rect.set(-r * 0.15f, -r * 0.62f, r * 0.15f, 0f); c.drawOval(rect, p)
                c.restore()
            }
            p.color = 0xFFFFF1C2.toInt(); c.drawCircle(0f, 0f, r * 0.14f, p)
            c.restore()
        }

        private fun fish(c: Canvas, f: Fish, w: Float, h: Float, t: Float) {
            val u = w / 400f * f.size
            val span = w + 260f * u
            val pos = (t * f.speed * w / 400f + f.phase * span) % span
            val x = if (f.dir > 0) -130f * u + pos else w + 130f * u - pos
            val y = h * f.yf + sin(t * 0.9f + f.phase * 6f) * h * 0.012f
            c.save(); c.translate(x, y); c.scale(f.dir * u, u)
            fresh(); p.style = Paint.Style.FILL
            p.color = f.color; p.alpha = 205; c.drawPath(finPath, p)
            c.save(); c.rotate(sin(t * 9f + f.phase * 5f) * 15f, 2f, 0f)
            p.color = f.color; p.alpha = 220; c.drawPath(tailPath, p)
            c.restore()
            p.color = f.color; c.drawPath(bodyPath, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.strokeCap = Paint.Cap.ROUND
            p.color = Color.argb(115, 255, 255, 255)
            c.drawLine(26f, -12f, 26f, 12f, p); c.drawLine(38f, -9f, 38f, 9f, p)
            p.style = Paint.Style.FILL
            p.color = Color.WHITE; c.drawCircle(47f, -3f, 3.2f, p)
            p.color = 0xFF120A14.toInt(); c.drawCircle(48f, -3f, 1.7f, p)
            c.restore()
        }
    }
}
