package com.myhindglobal.bellavite

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.View
import java.security.MessageDigest
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** One screen: choose a theme or your own gallery photo, edit the footer name, apply the wallpaper, share. */
class MainActivity : Activity() {

    // TODO: put the real APK / download link here before sharing
    private val appLink = "https://"
    private val reqPhoto = 101
    private lateinit var group: RadioGroup

    private val themeNames = arrayOf("🐟 रंग-बिरंगी मछलियाँ", "🌸 फूल", "💧 झरना", "⛰ पहाड़")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(View(this).apply { setBackgroundColor(0xFF120A14.toInt()) })
        askPin { buildUi() }
    }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(("bv-salt:$s").toByteArray()).joinToString("") { "%02x".format(it) }

    /** Settings (name, background, photo) open only after the PIN, so children or others cannot change them. */
    private fun askPin(onOk: () -> Unit) {
        val prefs = getSharedPreferences("bv", MODE_PRIVATE)
        val saved = prefs.getString("pin", null)
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(InputFilter.LengthFilter(4))
            hint = "● ● ● ●"
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(if (saved == null) "नया 4 अंकों का PIN बनाइए" else "PIN डालिए")
            .setMessage("सेटिंग बदलने के लिए PIN ज़रूरी है")
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("ठीक है", null)
            .setNegativeButton("बंद करें") { _, _ -> finish() }
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val v = et.text.toString()
                if (v.length != 4) { et.error = "4 अंक डालिए"; return@setOnClickListener }
                if (saved == null) {
                    prefs.edit().putString("pin", sha(v)).apply(); dlg.dismiss(); onOk()
                } else if (sha(v) == saved) {
                    dlg.dismiss(); onOk()
                } else { et.error = "गलत PIN"; et.setText("") }
            }
        }
        dlg.show()
    }

    private fun buildUi() {
        val prefs = getSharedPreferences("bv", MODE_PRIVATE)
        val dp = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF120A14.toInt())
            setPadding((24 * dp).toInt(), (48 * dp).toInt(), (24 * dp).toInt(), (24 * dp).toInt())
        }

        fun label(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { onClick() }
        }

        root.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            layoutParams = LinearLayout.LayoutParams((84 * dp).toInt(), (84 * dp).toInt())
        })
        root.addView(label("BellaVite लाइव घड़ी", 24f, 0xFFFFF1C2.toInt()))

        root.addView(label("1. अपनी पसंद का वॉलपेपर चुनिए:", 15f, 0xFFB9A58A.toInt()))
        group = RadioGroup(this)
        themeNames.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply { id = 100 + i; text = n; setTextColor(Color.WHITE) })
        }
        val cur = prefs.getInt("theme", 0)
        if (cur in themeNames.indices) group.check(100 + cur)
        group.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("theme", id - 100).apply()
        }
        root.addView(group)
        root.addView(button("🖼 या अपनी गैलरी से कोई भी फोटो चुनें") { pickPhoto() })
        root.addView(label("फोटो सिर्फ़ आपके फोन में रहती है, कहीं भेजी नहीं जाती।", 12f, 0xFF8D7A5C.toInt()))

        root.addView(label("2. घड़ी के नीचे का नाम (अपना या कंपनी का):", 15f, 0xFFB9A58A.toInt()))
        val et = EditText(this).apply {
            setText(prefs.getString("name", DEFAULT_NAME))
            setTextColor(Color.WHITE)
            filters = arrayOf(InputFilter.LengthFilter(28))
        }
        root.addView(et)

        fun currentName(): String = et.text.toString().trim().ifEmpty { DEFAULT_NAME }

        root.addView(button("नाम सेव करें") {
            prefs.edit().putString("name", currentName()).apply()
            Toast.makeText(this, "सेव हो गया", Toast.LENGTH_SHORT).show()
        })
        root.addView(label("3. फोन पर लगाइए:", 15f, 0xFFB9A58A.toInt()))
        root.addView(button("वॉलपेपर लगाएँ") {
            prefs.edit().putString("name", currentName()).apply()
            applyWallpaper()
        })
        root.addView(button("WhatsApp पर शेयर करें") { share(currentName()) })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(i, "फोटो चुनें"), reqPhoto)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == reqPhoto && resultCode == RESULT_OK && uri != null) {
            if (savePhoto(uri)) {
                getSharedPreferences("bv", MODE_PRIVATE).edit()
                    .putInt("theme", THEME_PHOTO)
                    .putLong("photo_ver", System.currentTimeMillis()).apply()
                group.clearCheck()
                Toast.makeText(this, "आपकी फोटो वॉलपेपर बन गई", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "फोटो नहीं खुल पाई, दूसरी चुनिए", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Copies the chosen photo into the app's private storage (downsized, rotation fixed). Nothing leaves the phone. */
    private fun savePhoto(uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val longSide = max(bounds.outWidth, bounds.outHeight)
            while (longSide / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp: Bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val orient = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val deg = when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                val m = Matrix(); m.postRotate(deg)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            FileOutputStream(File(filesDir, "bg.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun applyWallpaper() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this, ClockWallpaperService::class.java))
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    private fun share(name: String) {
        val msg = "🪔 नमस्कार!\n\n$name की तरफ़ से आपके लिए एक छोटा-सा डिजिटल गिफ्ट 🎁\n\n" +
            "✨ एक खूबसूरत लाइव घड़ी, जो आपके फोन की स्क्रीन पर वॉलपेपर बनकर हमेशा चलती रहेगी। " +
            "मछलियाँ, फूल, झरना या पहाड़ चुनिए, या अपने परिवार या मंदिर की फोटो लगाइए। " +
            "दिन-तारीख़ और हर त्योहार की शुभकामना अपने आप।\n\n" +
            "👉 डाउनलोड करें:\n$appLink\n\n" +
            "ऐप खोलकर “वॉलपेपर लगाएँ” दबाइए। चाहें तो अपना नाम भी लिख सकते हैं, बिल्कुल फ्री।\n\n" +
            "इसे दोस्तों और परिवार को फॉरवर्ड कर दीजिए। 🙏\n\n" +
            "शुभकामना सहित,\n*$name*\nPowered by ION (My Hind Global)"
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, msg) }
        startActivity(Intent.createChooser(i, "शेयर करें"))
    }
}
