# BellaVite Live Wallpaper (Android)
Powered by ION (My Hind Global)

Live analog clock as a real Android live wallpaper, with 4 built-in backgrounds (fish, flowers, waterfall, mountains) or the customer's own gallery photo (family, temple, home...), festival greetings and an editable footer name. Photos stay on the phone.

## Build the APK
Option A, Android Studio: open this folder, then Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
Option B, GitHub (no setup): push this folder to a new GitHub repo. The workflow in .github/workflows/build.yml builds the APK. Download it from Actions > latest run > Artifacts > BellaVite-APK.

## Before sharing
- Replace `appLink` in MainActivity.kt with the real download link.
- Replace the placeholder icon (android:icon in AndroidManifest.xml) with a logo.
- Festival dates in Festivals.kt cover 2026-2027; extend yearly. Eid is computed from the Hijri calendar and can differ by a day.
- Debug-signed APK is fine for direct sharing (users must allow "Install unknown apps"). Use a release keystore for Play Store.

## Disabled future modules (My Hind Global phase 2)
Subscription, referral, hidden SOS and OTA updates are NOT included in this build. Add them behind flags once the backend exists. SOS must be opt-in with the user's own emergency contacts and location permission.
